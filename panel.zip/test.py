import random
import time
import os

import sys

print("User Current Version:-", sys.version)